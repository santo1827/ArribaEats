﻿using System;

namespace ArribaEats
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Menu.ShowStartupMenu();
        }
    }
}